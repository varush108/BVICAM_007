

<html>

<form action="index.php" method="post" >
<input type="text" name="table" required>Table Name : </input>
<button type="submit">Generate PDF </button>
</form>

</html>

 

