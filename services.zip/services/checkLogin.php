<?php

require_once '../config.php';

if($_SERVER["REQUEST_METHOD"] == "POST"){
$password_err=false;
	$email = $_POST["emailLog"];
	$password= $_POST["passwordLog"];
	$sql = "SELECT UID,email,fullname,user_type,password_hash,images FROM users WHERE email = :email and is_active=1 and is_deleted=0";
        
        if($stmt = $pdo->prepare($sql)){
            // Bind variables to the prepared statement as parameters
            $stmt->bindParam(':email', $param_email, PDO::PARAM_STR);
            
            // Set parameters
            $param_email = trim($_POST["emailLog"]);
            
            // Attempt to execute the prepared statement
            if($stmt->execute()){
                // Check if username exists, if yes then verify password
                if($stmt->rowCount() == 1){
					
                    if($row = $stmt->fetch()){
                        $hashed_password = $row['password_hash'];
                        if(password_verify($password, $hashed_password)){
                            /* Password is correct, so start a new session and
                            save the username to the session */
							session_start();
							$_SESSION['logged_in']=true;
                            $_SESSION['UID'] = $row['UID'];
							$_SESSION['name'] = $row['fullname'];	
							 $_SESSION['role'] = $row['user_type'];
							  $_SESSION['email'] = $row['email'];
							  $_SESSION['image'] = $row['images'];
							$password_err=false;							
                            
                        }
						else
						{
							//echo "Password error";
							$password_err=true;
						}
					}
				}
			}
		}
		echo $password_err;
					
	
}

?>