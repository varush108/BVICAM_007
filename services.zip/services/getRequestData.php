<?php
 
 require_once '../config.php';
 $result=array();
 $sql = "SELECT request_details.visits,request_details.ref_no, request_details.status,request_details.building_address,user.name,
		user.email,user.phoneNo ,inspectors.rating,inspectors.rank
		FROM request_details,user ,inspectors
		WHERE request_details.inspector_allocated = user.UID  AND request_details.user_id= :user_id AND
		inspectors.user_id=request_details.inspector_allocated" ;
       
        if($stmt = $pdo->prepare($sql)){
            // Bind variables to the prepared statement as parameters
            $stmt->bindParam(':user_id', $param_userid);
			
            // Set parameters
            $param_userid = trim($_GET["user_id"]);
            
            // Attempt to execute the prepared statement
            if($stmt->execute()){
				echo "executed";
                if($stmt->rowCount() == 1){
				$result["refNo"]=$row["ref_no"];
				$result["visits"]=$row["visits"];
				$result["status"]=$row["status"];
				$result["address"]=$row["building_address"];
				$result["InspectorName"]=$row["name"];
				$result["InspectorEmail"]=$row["email"];
				$result["InspectorMobile"]=$row["phoneNo"];
				$result["InspectorRank"]=$row["rank"];
				$result["InspectorRatings"]=$row["rating"];
					 print_r($result);
				
				} else{
					
					echo false;
                    
                }
            } else{
                echo "error";
            }
        }
?>