
<html>
<form action="send1.php" method="post">
Phone : <input name="number"/>
<input type="submit"/>
</form>
</html>
 